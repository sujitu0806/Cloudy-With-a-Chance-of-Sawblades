from cmu_graphics import *
from PIL import Image
import math
import random
import time
import os

def onAppStart(app):

    app.sprite = 'Dude_Monster.png' 
    app.spriteRunRight = ['Dude_Monster_Run_1.png', 
                     'Dude_Monster_Run_2.png', 
                     'Dude_Monster_Run_3.png', 
                     'Dude_Monster_Run_4.png', 
                     'Dude_Monster_Run_5.png',
                     'Dude_Monster_Run_6.png'] 

    app.spriteRunLeft = ['runFlip1.png', 
                        'runFlip2.png', 
                        'runFlip3.png', 
                        'runFlip4.png', 
                        'runFlip5.png', 
                        'runFlip6.png']
    
    '''app.spriteJumpRight = ['Dude_Monster_Jump_1.png',
                           'Dude_Monster_Jump_2.png',
                           'Dude_Monster_Jump_3.png',
                           'Dude_Monster_Jump_4.png',
                           'Dude_Monster_Jump_5.png',
                           'Dude_Monster_Jump_6.png',
                           'Dude_Monster_Jump_7.png',
                           'Dude_Monster_Jump_8.png',]'''
    
    app.spriteJumpRightUp = ['Dude_Monster_Jump_1.png',
                           'Dude_Monster_Jump_2.png',
                           'Dude_Monster_Jump_3.png',
                           'Dude_Monster_Jump_4.png']
    
    app.spriteJumpRightDown = ['Dude_Monster_Jump_5.png',
                                'Dude_Monster_Jump_6.png',
                                'Dude_Monster_Jump_7.png',
                                'Dude_Monster_Jump_8.png']
    
    '''app.spriteJumpLeft = ['Dude_Monster_Jump_1Flip.png',
                          'Dude_Monster_Jump_2Flip.png',
                          'Dude_Monster_Jump_3Flip.png',
                          'Dude_Monster_Jump_4Flip.png',
                          'Dude_Monster_Jump_5Flip.png',
                          'Dude_Monster_Jump_6Flip.png',
                          'Dude_Monster_Jump_7Flip.png',
                          'Dude_Monster_Jump_8Flip.png']'''
    
    app.spriteJumpLeftUp = ['Dude_Monster_Jump_1Flip.png',
                          'Dude_Monster_Jump_2Flip.png',
                          'Dude_Monster_Jump_3Flip.png',
                          'Dude_Monster_Jump_4Flip.png']

    app.spriteJumpLeftDown = ['Dude_Monster_Jump_5Flip.png',
                          'Dude_Monster_Jump_6Flip.png',
                          'Dude_Monster_Jump_7Flip.png',
                          'Dude_Monster_Jump_8Flip.png',]
    
            
    app.spriteIdleRight = ['Dude_Monster_Idle_1.png',
                           'Dude_Monster_Idle_2.png',
                           'Dude_Monster_Idle_3.png',
                           'Dude_Monster_Idle_4.png',]
    
    app.spriteIdleLeft = ['Dude_Monster_Idle_1Flip.png',
                          'Dude_Monster_Idle_2Flip.png',
                          'Dude_Monster_Idle_3Flip.png',
                          'Dude_Monster_Idle_4Flip.png',]
    


    app.isRunning = False   
    app.facingRight = True
    app.runFrame = 0  
    app.runTimer = 0   
    app.runSpeed = 4          

    app.isJumping = False
    app.jumpFrame = 0
    app.jumpTimer = 0
    app.jumpSpeed = 2

    app.idleFrame = 0
    app.idleTimer = 0
    app.idleSpeed = 4

    app.stepDelay = 20
    app.stepsPerSecond = 32
    app.backgroundX = app.width/2 - 161
    app.backgroundY = 20
    app.backgroundWidth = 322
    app.backgroundColor = 'white'
    app.backgroundHeight = 360
    app.dy = 0
    app.ay = 1.2
    app.timer = 1920
    app.displayTimer = 60
    app.timerBarX = app.width/2 - 161
    app.timerBarY = 386
    app.timerBarHeight = 20

    app.alive = True

    app.gems = []

    app.sawblades = []
    app.sawbladesLength = 1
    app.sawbladeColor = 'red'
    app.specialSawblade = None
    #makeSawblades(app) 

    app.specialSawblade = []

    app.starAngle = 0

    app.jumps = 0
    app.jumpHoldTime = 0
    app.maxJumpHoldTime = 12
    app.isHoldingJump = False 

    app.widthHalf = 16.5
    app.heightHalf = 21.5

    app.cx = app.width/2
    app.cy = 360 - app.heightHalf
    app.r = 14

    app.umbrellaActive = False
    app.umbrellaCount = 3
    app.umbrellaHalfWidth = 50
    app.umbrellaAngle = 0
    app.umbrellaX = app.cx - app.umbrellaHalfWidth
    app.umbrellaY = app.cy - 75
    app.umbrellaTimer = 10
    app.umbrellaFacingAngle = 0

    app.lineX1 = app.umbrellaX - app.umbrellaHalfWidth + 15
    app.lineY1 = app.umbrellaY
    app.lineX2 = app.umbrellaX + app.umbrellaHalfWidth - 15
    app.lineY2 = app.umbrellaY
    app.canSee = True

    app.score = 0

def redrawAll(app):

    if app.alive:

        drawRect(0, 0, 400, 500, fill = 'lightBlue')
        drawRect(app.backgroundX, app.backgroundY, app.backgroundWidth, app.backgroundHeight, fill = app.backgroundColor)
        #drawImage('snow.jpg', app.backgroundX, app.backgroundY, width = app.backgroundWidth, height = app.backgroundHeight)
        drawRect(app.backgroundX, 0, app.backgroundWidth, 20, fill = app.backgroundColor)
        drawLabel(app.score, app.width/2 + 5, 205, size=130, fill = 'grey', bold = True, font='comicSans', opacity=60)
        drawLabel(app.score, app.width/2, 200, size=130, fill = 'red', bold = True, font='comicSans', opacity=60)

        if app.isJumping: 
            if app.facingRight: 
                if app.dy < 0:
                    if app.jumpFrame == 3:
                        drawImage(app.spriteJumpRightUp[app.jumpFrame], app.cx - 16.5, app.cy - 30, width=28, height=43) 
                    else:
                        drawImage(app.spriteJumpRightUp[app.jumpFrame], app.cx - 16.5, app.cy - 30, width=33, height=43) 
                else:
                    drawImage(app.spriteJumpRightDown[app.jumpFrame], app.cx - 16.5, app.cy - 30, width=33, height=43)
            else: 
                if app.dy < 0:
                    if app.jumpFrame == 3:
                        drawImage(app.spriteJumpLeftUp[app.jumpFrame], app.cx - 16.5, app.cy - 30, width=28, height=43) 
                    else:
                        drawImage(app.spriteJumpLeftUp[app.jumpFrame], app.cx - 16.5, app.cy - 30, width=33, height=43) 
                else:
                    drawImage(app.spriteJumpLeftDown[app.jumpFrame], app.cx - 16.5, app.cy - 30, width=33, height=43)
                
        elif app.isRunning:
            if app.facingRight:
                drawImage(app.spriteRunRight[app.runFrame], app.cx - 16.5, app.cy - app.heightHalf, width=33, height=43)
            else:
                drawImage(app.spriteRunLeft[app.runFrame], app.cx - 16.5, app.cy - app.heightHalf, width=33, height=43)
        else: 
            if app.facingRight:
                drawImage(app.spriteIdleRight[app.idleFrame], app.cx - 16.5, app.cy - app.heightHalf, width=29, height=43)
            else:
                drawImage(app.spriteIdleLeft[app.idleFrame], app.cx - 16.5, app.cy - app.heightHalf, width=29, height=43)

        if app.umbrellaActive: 
            drawImage('umbrella.png', app.umbrellaX - app.umbrellaHalfWidth, app.umbrellaY - 50, width=100, height=100, rotateAngle=app.umbrellaAngle)
            drawLine(app.lineX1, app.lineY1, app.lineX2, app.lineY2, rotateAngle=app.umbrellaAngle, fill = 'White')
            drawCircle(app.cx, app.cy, 55, fill = None, border = 'black')

        for sawblade in app.sawblades:
            drawStar(sawblade.xCoord, sawblade.yCoord, 20, 8, fill='white', border='black', borderWidth=3, rotateAngle=-app.starAngle, roundness=75)
            drawCircle(sawblade.xCoord, sawblade.yCoord, 10, fill= sawblade.color)
        
        for specialSawblade in app.specialSawblade: 
            drawStar(specialSawblade.xCoord, specialSawblade.yCoord, specialSawblade.radius, 8, fill='white', border='black', borderWidth=3, rotateAngle=-app.starAngle, roundness=75) 
            drawCircle(specialSawblade.xCoord, specialSawblade.yCoord, 10, fill=specialSawblade.color)
            if app.canSee:
                drawLine(specialSawblade.xCoord, specialSawblade.yCoord, app.cx, app.cy, fill = 'red', dashes = True, arrowStart=False, arrowEnd=True)
            else:
                drawLine(specialSawblade.xCoord, specialSawblade.yCoord, app.cx, app.cy, fill = 'black', dashes = True, arrowStart=False, arrowEnd=False)

        for gem in app.gems:
            drawCircle(gem.xCoord, gem.yCoord, gem.radius, fill=gem.color, border = 'black')
        
        drawRect(app.timerBarX, app.timerBarY, app.backgroundWidth, app.timerBarHeight, fill = app.backgroundColor)
        drawRect(app.timerBarX, app.timerBarY, ((app.displayTimer / 60) * app.backgroundWidth), app.timerBarHeight, fill = 'gold')
        drawLabel(app.displayTimer, app.width/2, 396, size = 18, fill = 'black', bold = True)

    else:
        drawLabel('Game', app.width/2, 120, size = 120, fill = 'red', bold = True, font='comicSans', opacity=40)
        drawLabel('Over!', app.width/2, 240, size = 120, fill = 'red', bold = True, font='comicSans', opacity=40)
        drawLabel(f"Press 'r' to restart", app.width/2, 340, size = 20, fill = 'red', bold = True, font='comicSans', opacity=40)

def onKeyPress(app, key):
    if app.alive:
        if key == 'up' and app.jumps < 2:
            app.isJumping = True
            if app.jumps == 0:
                app.isHoldingJump = True
                app.jumpFrame = 0
                app.jumpHoldTime = 0
                app.dy = -5
            elif app.jumps == 1:
                app.dy = -11
                app.jumpFrame = 0
                app.jumps += 1

        if key == 'right':
            if not app.isJumping:
                app.isRunning = True
            app.facingRight = True

        if key == 'left':
            if not app.isJumping:
                app.isRunning = True 
            app.facingRight = False 

        if key == 'w' and app.umbrellaCount > 0: 
            app.umbrellaActive = True 
            app.umbrellaX = app.cx 
            app.umbrellaY = app.cy - 50
            app.umbrellaCount -= 1 
            app.umbrellaAngle = 0

    else:
        if key == 'r':
            onAppStart(app)

def onKeyRelease(app, key):
    if key == 'up' and app.isHoldingJump:
        app.isHoldingJump = False
        app.jumps += 1

    if (key == 'right' or key == 'left') and not app.isJumping:
        app.isRunning = False
        app.runFrame = 0

def onKeyHold(app, keys):

    if 'right' in keys and not app.isJumping:
        app.cx = min(app.cx + 7, app.backgroundX + app.backgroundWidth - app.widthHalf)
        app.isRunning = True
    elif 'left' in keys and not app.isJumping:
        app.cx = max(app.cx - 7, app.backgroundX + app.widthHalf)
        app.isRunning = True
    
    if 'right' in keys and app.isJumping:
        app.cx = min(app.cx + 7, app.backgroundX + app.backgroundWidth - app.widthHalf)
    elif 'left' in keys and app.isJumping:
        app.cx = max(app.cx - 7, app.backgroundX + app.widthHalf)

    if app.umbrellaActive: 

        if 'a' in keys: 
            app.umbrellaAngle -= 8
        elif 'd' in keys: 
            app.umbrellaAngle += 8
        
def onStep(app):
    if app.isHoldingJump and app.jumps == 0:
        if app.jumpHoldTime < app.maxJumpHoldTime:
            app.jumpHoldTime += 1
            holdFactor = (1 - (app.jumpHoldTime / app.maxJumpHoldTime)) ** 1.65
            app.dy = -6.5 - (6.5 * holdFactor)

    if app.isRunning:
        app.runTimer += 1
        if app.runTimer % app.runSpeed == 0:
            app.runFrame = (app.runFrame + 1) % len(app.spriteRunRight)

    if app.isJumping: 
        singleJumpPeak = app.backgroundY + app.heightHalf - app.maxJumpHoldTime * app.ay
        doubleJumpPeak = singleJumpPeak - 11

        heightRatio = 1

        if app.jumps == 0: 
            heightRatio = (app.cy - app.backgroundY) / singleJumpPeak 
        elif app.jumps == 1: 
            heightRatio = (app.cy - app.backgroundY) / doubleJumpPeak

        app.jumpSpeed = max(int(100 / (heightRatio + 0.1)), 1)

        app.jumpTimer += 1 
        if app.jumpTimer % app.jumpSpeed == 0: 
            if app.dy < 0:
                app.jumpFrame = (app.jumpFrame + 1) % len(app.spriteJumpRightUp)
                if app.facingRight: 
                    app.currentSprite = app.spriteJumpRightUp[app.jumpFrame] 
                else: 
                    app.currentSprite = app.spriteJumpLeftUp[app.jumpFrame]

            elif app.dy > 0:
                app.jumpFrame = (app.jumpFrame + 1) % len(app.spriteJumpRightDown)
                if app.facingRight: 
                    app.currentSprite = app.spriteJumpRightDown[app.jumpFrame] 
                else: 
                    app.currentSprite = app.spriteJumpLeftDown[app.jumpFrame]
    
    if app.isRunning == False:
        app.idleTimer += 1
        if app.idleTimer % app.idleSpeed == 0:
            app.idleFrame = (app.idleFrame + 1) % len(app.spriteIdleRight)

    app.dy += app.ay
    app.cy += app.dy 

    if app.cy + app.heightHalf > app.backgroundY + app.backgroundHeight:
        app.cy = app.backgroundY + app.backgroundHeight - app.heightHalf
        app.dy = 0 
        app.jumps = 0
        app.jumpFrame = 0
        app.isJumping = False
        app.isRunning = False

    if app.cy - app.heightHalf < app.backgroundY:
        app.cy = app.backgroundY + app.heightHalf
        app.dy = 0

    for sawblade in app.sawblades:
        sawblade.move()
        bounceHorizontallySawblade(app, sawblade)
        bounceVerticallySawblade(app, sawblade)
    
    if app.score < 2:
        app.sawbladesLength = 1
    elif app.score < 10:
        app.sawbladesLength = 2
    elif app.score < 25:
        app.sawbladesLength = 3
    elif app.score < 45:
        app.sawbladesLength = 4
    else:
        app.sawbladesLength = 5

    if len(app.sawblades) < app.sawbladesLength:
        if random.random() < 0.03:
            makeSawblades(app)
    
    app.starAngle -= 20

    for gem in app.gems:
        gem.dy += app.ay
        gem.yCoord += gem.dy

        gem.xCoord += gem.dx
        gem.dx *= 0.98

        if gem.yCoord + gem.radius > app.backgroundY + app.backgroundHeight:
            gem.yCoord = app.backgroundY + app.backgroundHeight - gem.radius
            gem.dy = -gem.dy * 0.5
            if abs(gem.dy) < 1:
                gem.dy = 0
                gem.dx = 0
        
        if gem.xCoord - gem.radius < app.backgroundX:
            gem.xCoord = app.backgroundX + gem.radius
            gem.dx = -gem.dx

        elif gem.xCoord + gem.radius > app.backgroundX + app.backgroundWidth:
            gem.xCoord = app.backgroundX + app.backgroundWidth - gem.radius
            gem.dx = -gem.dx

    app.timer -= 1
    app.displayTimer = math.ceil(app.timer/32)

    if app.umbrellaActive: 
        distanceToPlayer = 30
        angleRadians = math.radians(app.umbrellaAngle) + (math.pi / 2)
        app.umbrellaX = app.cx + distanceToPlayer * (-math.cos(angleRadians))
        app.umbrellaY = app.cy - distanceToPlayer * (math.sin(angleRadians))
        app.lineX1 = app.umbrellaX - app.umbrellaHalfWidth + 15 
        app.lineY1 = app.umbrellaY 
        app.lineX2 = app.umbrellaX + app.umbrellaHalfWidth - 15
        app.lineY2 = app.umbrellaY
        #print(f"Umbrella Active: {app.umbrellaActive}")
        #print(f"Umbrella Line: ({app.lineX1}, {app.lineY1}) to ({app.lineX2}, {app.lineY2})")

    for specialSawblade in app.specialSawblade:
        specialSawblade.moveTowardsPlayer(app, app.cx, app.cy)
        #print(f"Sawblade at ({specialSawblade.xCoord}, {specialSawblade.yCoord})")
        #print(f"canSee Result: {canSee(specialSawblade.xCoord, specialSawblade.yCoord, app.cx, app.cy, app.lineX1, app.lineY1, app.lineX2, app.lineY2)}")

    checkPlayerJumpOver(app)
    checkPlayerJumpOverSpecial(app)
    collisionCheckerBlade(app)
    collisionCheckerGem(app)
    checkSpecialSawbladeCollision(app)
    pathTrackingSawbladeMaker(app)
    checkTimer(app)

def checkPlayerJumpOver(app):
    sawbladesToRemove = []
    for sawblade in app.sawblades:
        if app.cy + app.heightHalf < sawblade.yCoord + 20 and abs(app.cx - sawblade.xCoord) <= 20:
            if sawblade.destroyTime is None:
                sawblade.destroyTime = time.time()
            sawblade.color = 'green'

    for sawblade in app.sawblades:
        if sawblade.destroyTime is not None and time.time() - sawblade.destroyTime >= 0.75:
            sawbladesToRemove.append(sawblade)

    for sawblade in sawbladesToRemove:
        app.sawblades.remove(sawblade)
        app.score += 1
        makeGems(app, sawblade.xCoord, sawblade.yCoord)

def checkPlayerJumpOverSpecial(app):
    specialSawbladesToRemove = []
    for specialSawblade in app.specialSawblade:
        if app.cy + app.heightHalf < specialSawblade.yCoord + 20 and abs(app.cx - specialSawblade.xCoord) <= 20:
            if specialSawblade.destroyTime is None:
                specialSawblade.destroyTime = time.time()
            specialSawblade.color = 'green'

    for specialSawblade in app.specialSawblade:
        if specialSawblade.destroyTime is not None and time.time() - specialSawblade.destroyTime >= 0.75:
            specialSawbladesToRemove.append(specialSawblade)

    for specialSawblade in specialSawbladesToRemove:
        app.specialSawblade.remove(specialSawblade)
        app.score += 1
        makeGems(app, specialSawblade.xCoord, specialSawblade.yCoord)
        makeGems(app, specialSawblade.xCoord, specialSawblade.yCoord)
        makeGems(app, specialSawblade.xCoord, specialSawblade.yCoord)
    
def distance(x0, y0, x1, y1):
    return ((x1 - x0)**2 + (y1 - y0)**2)**0.5

def checkSpecialSawbladeCollision(app):
    for specialSawblade in app.specialSawblade:
        xLength = abs(app.cx - specialSawblade.xCoord)
        yLength = abs(app.cy - specialSawblade.yCoord)

        if xLength - app.widthHalf < -2 and yLength - app.heightHalf < -2:
            app.alive = False

def collisionCheckerBlade(app):
    for sawblade in app.sawblades:

        xLength = abs(app.cx - sawblade.xCoord)
        yLength = abs(app.cy - sawblade.yCoord)

        if xLength - app.widthHalf < -2 and yLength - app.heightHalf < -2:
            app.alive = False

def collisionCheckerGem(app):
    for gem in app.gems:

        xLength = abs(app.cx - gem.xCoord)
        yLength = abs(app.cy - gem.yCoord)

        if xLength - app.widthHalf < 5 and yLength - app.heightHalf < 5:
            app.gems.remove(gem)
            app.timer += 32

def bounceHorizontallySawblade(app, sawblade):
    #sawblade.xCoord += sawblade.sawbladeDX
    if sawblade.xCoord + sawblade.radius >= app.backgroundX + app.backgroundWidth:
        sawblade.xCoord = (app.backgroundX + app.backgroundWidth) - sawblade.radius
        sawblade.sawbladeDX = -sawblade.sawbladeDX
    elif sawblade.xCoord - sawblade.radius <= app.backgroundX:
        sawblade.xCoord = app.backgroundX + sawblade.radius
        sawblade.sawbladeDX = -sawblade.sawbladeDX

def bounceVerticallySawblade(app, sawblade):
    #sawblade.yCoord += sawblade.sawbladeDY

    if sawblade.yCoord + sawblade.radius >= app.backgroundY + app.backgroundHeight:
        sawblade.yCoord = (app.backgroundY + app.backgroundHeight) - sawblade.radius
        sawblade.sawbladeDY = -sawblade.sawbladeDY

    for sawblade in app.sawblades:
        if sawblade.yCoord + sawblade.radius + 100 <= 0:
            app.sawblades.remove(sawblade)

def checkTimer(app):
    if app.displayTimer <= 0:
        app.alive = False

def makeGems(app, sawbladeX, sawbladeY):
    gem = gems(sawbladeX, sawbladeY, 6)
    gem.dy = -15
    gem.dx = random.uniform(-3, 3)
    app.gems.append(gem)

def makeSawblades(app):
    randomX = random.randint(70, 330)
    yCoord = 0
    sawbladeDX = random.choice([random.uniform(-6, -4), random.uniform(4, 6)])
    sawbladeDY = 5
    radius = 20
    sawblade = sawblades(randomX, yCoord, sawbladeDX, sawbladeDY, radius, app.cx, app.cy, 55)
    app.sawblades.append(sawblade)

def pathTrackingSawbladeMaker(app):
    randomNum = random.randint(1, 100)
    if randomNum == 52:
        if app.score >= 5 and len(app.specialSawblade) == 0:
            makeSpecialSawblades(app)

    '''if len(app.specialSawblade) == 0:
        makeSpecialSawblades(app)'''

def makeSpecialSawblades(app):
    randomX = random.randint(70, 330)
    yCoord = 0
    radius = 20
    special = specialSawblade(randomX, yCoord, radius, app.cx, app.cy, 55)
    app.specialSawblade.append(special)

class sawblades:
    def __init__(self, xCoord, yCoord, sawbladeDX, sawbladeDY, radius, cx, cy, cr):
        self.xCoord = xCoord
        self.yCoord = yCoord
        self.color = 'red'
        self.sawbladeDX = sawbladeDX
        self.sawbladeDY = sawbladeDY
        self.radius = radius
        self.destroyTime = None
        self.cx = cx # Center x of the umbrella circle 
        self.cy = cy # Center y of the umbrella circle 
        self.cr = cr # Radius of the umbrella circle

    def checkCollision(self): 
        nextX = self.xCoord + self.sawbladeDX
        nextY = self.yCoord + self.sawbladeDY
        
        # Vector from the sawblade to the umbrella's center
        dxUmbrella = self.cx - self.xCoord
        dyUmbrella = self.cy - self.yCoord
        
        # Vector representing the sawblade's movement
        dxMovement = nextX - self.xCoord
        dyMovement = nextY - self.yCoord
        
        # Check if the distance from the sawblade's path to the umbrella center is less than the sum of their radii
        distance = math.sqrt(dxUmbrella**2 + dyUmbrella**2)
        if distance < self.cr + self.radius: 
            return True 
        return False

        '''distance = math.sqrt((self.xCoord - self.cx)**2 + (self.yCoord - self.cy)**2) 
        if distance < self.cr + self.radius: 
            return True 
        return False'''

    def bounceOffUmbrella(self, contactX, contactY): 
        alpha = findAlpha(contactX, contactY, self.sawbladeDX, self.sawbladeDY, self.cx, self.cy) # Calculate new direction using alpha 
        magnitude = math.sqrt(self.sawbladeDX**2 + self.sawbladeDY**2) 
        self.sawbladeDX = magnitude * math.cos(alpha) 
        self.sawbladeDY = magnitude * -math.sin(alpha) 
        #print(f"New direction: DX={self.DX}, DY={self.DY}")

    def move(self): 
        self.xCoord += self.sawbladeDX 
        self.yCoord += self.sawbladeDY # Check collision with umbrella 
        if self.checkCollision(): 
            self.bounceOffUmbrella(self.xCoord, self.yCoord) # Handle screen bounds 

class gems:
    def __init__(self, xCoord, yCoord, radius):
        self.xCoord = xCoord
        self.yCoord = yCoord
        self.color = 'gold'
        self.radius = radius
        self.dy = 0
        self.dx = 0

def findAlpha(contactX, contactY, dx, dy, cx, cy): # Calculate the derivative of the tangent 
    derivative = -(contactX - cx) / (contactY - cy) 
    theta = math.atan(derivative) 

    if dx == 0: 
        if dy > 0: 
            beta = math.pi / 2 # 90 degrees in radians 
        else: beta = -math.pi / 2 # -90 degrees in radians 

    else: beta = math.atan(dy / dx)

    alpha = math.pi / 2 - beta - theta # 90 degrees in radians 
    return alpha

class specialSawblade:
    def __init__(self, xCoord, yCoord, radius, cx, cy, cr):
        self.xCoord = xCoord
        self.yCoord = yCoord
        self.color = 'gold'
        self.radius = radius
        self.destroyTime = None
        self.speed = 4
        self.DX = 0
        self.DY = 0
        self.tracking = True
        self.cx = cx # Center x of the circle (umbrella) 
        self.cy = cy # Center y of the circle (umbrella) 
        self.cr = cr # Radius of the circle (umbrella)

    def checkCollision(self): 
        distance = math.sqrt((self.xCoord - self.cx)**2 + (self.yCoord - self.cy)**2) 
        if distance < self.cr + self.radius: 
            return True 
        return False

    def bounceOffUmbrella(self, contactX, contactY): 
        alpha = findAlpha(contactX, contactY, self.DX, self.DY, self.cx, self.cy) # Calculate new direction using alpha 
        magnitude = math.sqrt(self.DX**2 + self.DY**2) 
        self.DX = magnitude * math.cos(alpha) 
        self.DY = magnitude * math.sin(alpha) 
        print(f"New direction: DX={self.DX}, DY={self.DY}")

    def moveTowardsPlayer(self, app, playerX, playerY):
        dx = playerX - self.xCoord
        dy = playerY - self.yCoord
        dist = ((dx)**2 + (dy)**2)**0.5

        if dist != 0:
            if app.umbrellaActive:
                if not canSee(self.xCoord, self.yCoord, playerX, playerY, app.lineX1, app.lineY1, app.lineX2, app.lineY2): 
                    print("Umbrella blocks the line of sight.")
                    app.canSee = False
                    #self.xCoord += self.speed # Move directly right return
                    if self.tracking: # If tracking, generate new DX and DY 
                        self.DX = random.choice([random.uniform(-6, -4), random.uniform(4, 6)])
                        self.DY = 3
                        self.tracking = False
                    bounceHorizontallySpecialSawblade(app, self) 
                    bounceVerticallySpecialSawblade(app, self)
                    '''if self.checkCollision():
                            contactX = self.xCoord 
                            contactY= self.yCoord
                            self.bounceOffUmbrella(contactX, contactY)'''

                else:
                    print("Doesn't block")
                    app.canSee = True
                    self.tracking = True
                    self.xCoord += self.speed * (dx / dist) 
                    self.yCoord += self.speed * (dy / dist)
            
            else:
                self.xCoord += self.speed * (dx / dist) 
                self.yCoord += self.speed * (dy / dist)
            
            if self.checkCollision():
                contactX = self.xCoord 
                contactY= self.yCoord
                self.bounceOffUmbrella(contactX, contactY)
            

def canSee(x1, y1, x2, y2, x3, y3, x4, y4):

    def determinant(a, b, c, d):
        return a * d - b * c
    
    def inBoundingBox(x, y, xMin, xMax, yMin, yMax): 
        return xMin - 1e-6 <= x <= xMax + 1e-6 and yMin - 1e-6 <= y <= yMax + 1e-6

    a1 = y2 - y1
    b1 = x1 - x2 
    c1 = a1 * x1 + b1 * y1

    a2 = y4 - y3 
    b2 = x3 - x4 
    c2 = a2 * x3 + b2 * y3

    det = determinant(a1, b1, a2, b2)
    print(f"Determinant: {det}")

    if det == 0:
        print("Lines are parallel")
        return True
    
    x = (b2 * c1 - b1 * c2) / det 
    y = (a1 * c2 - a2 * c1) / det
    print(f"Intersection Point: ({x}, {y})")

    margin = 0

    inBox1 = inBoundingBox(x, y, min(x1, x2), max(x1, x2), min(y1, y2), max(y1, y2))
    inBox2 = inBoundingBox(x, y, min(x3, x4), max(x3, x4), min(y3, y4), max(y3, y4))
    print(f"In Box 1: {inBox1}, In Box 2: {inBox2}")

    if inBox1 and inBox2: 
        print("Intersection is within both bounding boxes") 
        return False 
    return True

def bounceHorizontallySpecialSawblade(app, specialSawblade): 
    specialSawblade.xCoord += specialSawblade.DX 
    if specialSawblade.xCoord + specialSawblade.radius >= app.backgroundX + app.backgroundWidth: 
        specialSawblade.xCoord = (app.backgroundX + app.backgroundWidth) - specialSawblade.radius 
        specialSawblade.DX = -specialSawblade.DX 
    elif specialSawblade.xCoord - specialSawblade.radius <= app.backgroundX: 
        specialSawblade.xCoord = app.backgroundX + specialSawblade.radius 
        specialSawblade.DX = -specialSawblade.DX 

def bounceVerticallySpecialSawblade(app, specialSawblade): 
    specialSawblade.yCoord += specialSawblade.DY 
    if specialSawblade.yCoord + specialSawblade.radius >= app.backgroundY + app.backgroundHeight: 
        specialSawblade.yCoord = (app.backgroundY + app.backgroundHeight) - specialSawblade.radius 
        specialSawblade.DY = -specialSawblade.DY # Optional: Remove special sawblades if they go out of bounds (example logic) 
        
        for specialSawblade in app.specialSawblade: 
            if specialSawblade.yCoord + specialSawblade.radius + 100 <= 0: 
                app.specialSawblade.remove(specialSawblade)

def main():
    runApp(width = 400, height = 500)

main()

    